package br.com.armeletex.core.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.armeletex.cliente.ClienteRepository;
import br.com.armeletex.restaurante.RestauranteFuncionarioRepository;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private ClienteRepository clienteRepository;

	@Autowired
	private RestauranteFuncionarioRepository restauranteFuncionarioRepository;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		AppUser cliente = clienteRepository.findByEmail(email);
		if (cliente == null) {
			cliente = restauranteFuncionarioRepository.findByEmail(email);
			if (cliente == null) {
				throw new UsernameNotFoundException(email);
			}
		}
		return new UserDetailsImpl(cliente);
	}

}
