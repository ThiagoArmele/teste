package br.com.armeletex.core.security;

public abstract class SecurityConstants {
	
	protected SecurityConstants() {
	 throw new IllegalStateException("Utility class");
	}
	
	public static final String AUTHORIZATION = "authorization";
	public static final String TOKEN_PREFIX = "Bearer ";
	public static final int TIME_EXPERATION = 86400000;
	public static final String SECRET_KEY = "theSeCRetKeY";
}
