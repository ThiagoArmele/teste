package br.com.armeletex.cliente;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;

import org.hibernate.validator.constraints.br.CPF;

import br.com.armeletex.core.security.AppUser;
import br.com.armeletex.empresa.Empresa;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "tb_cliente")
public class Cliente extends AppUser {

	@Id
	@GeneratedValue
	@Column(name = "id_cliente", length = 9)
	private int id;

	@OneToOne
	@JoinColumn(name = "id_empresa")
	private Empresa empresa;

	@Column(name = "admin", columnDefinition = "TINYINT(1) DEFAULT 0")
	private boolean admin;

	@Column(name = "beta_tester")
	private boolean betaTester;

	@CPF(message = "CPF inv�lido")
	@NotEmpty(message = "CPF obrigat�rio")
	@Column(name = "cpf", length = 11)
	private String cpf;

	@Column(name = "hash")
	private Integer hash;

}
