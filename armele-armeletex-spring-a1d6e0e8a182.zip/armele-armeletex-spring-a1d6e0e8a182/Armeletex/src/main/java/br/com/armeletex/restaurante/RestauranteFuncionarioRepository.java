package br.com.armeletex.restaurante;

import org.springframework.stereotype.Repository;

import br.com.armeletex.core.AppUserRepository;

@Repository
public interface RestauranteFuncionarioRepository extends AppUserRepository<RestauranteFuncionario> {

}
