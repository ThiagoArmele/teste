package br.com.armeletex.restaurante;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.armeletex.core.security.AppUser;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "tb_restaurante_funcionario")
public class RestauranteFuncionario extends AppUser {

	@Id
	@GeneratedValue
	@Column(name = "id_restaurante_funcionario")
	private int id;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "id_restaurante")
	private Restaurante restaurante;

}
