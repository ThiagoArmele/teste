package br.com.armeletex.restaurate.mercadoria;

import br.com.armeletex.core.CrudRestaurantRepository;


public interface EmbalagemRepository extends CrudRestaurantRepository<Embalagem> {

}
