package br.com.armeletex.core;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

@NoRepositoryBean
public interface CrudRestaurantRepository<T> extends CrudRepository<T, Integer>{

	@Override
	@Query("select f from Finalizadora f where f.restaurante = "
			+ "(select rf.restaurante from RestauranteFuncionario rf where rf.email = ?#{principal})")
	List<T> findAll();
	
	@Override
	@Query("select f from Finalizadora f where f.restaurante = "
			+ "(select rf.restaurante from RestauranteFuncionario rf where rf.email = ?#{principal}) "
			+ "and f.id = ?1")
	Optional<T> findById(Integer id);
	
}
