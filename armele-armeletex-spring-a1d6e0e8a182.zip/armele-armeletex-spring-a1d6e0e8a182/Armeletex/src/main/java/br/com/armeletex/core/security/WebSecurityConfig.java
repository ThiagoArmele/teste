package br.com.armeletex.core.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter implements WebMvcConfigurer {
	
	@Bean
	public AuthenticationSuccessHandler authenticationSuccessHandler() {
		return new AuthenticationSuccessHandlerImpl();
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable().cors().disable().httpBasic().and()
				.authorizeRequests()
				.antMatchers("/api/cliente/**").hasRole(TipoRole.CLIENTE.toString())
				.antMatchers("/api/restaurante/**").hasRole(TipoRole.RESTAURANTE.toString())
				.anyRequest().authenticated()
				.and()
				.addFilter(new JWTAuthenticationFilter(authenticationManager()))
				.addFilter(new JWTAuthorizationFilter(authenticationManager())).sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
					.formLogin()
					.loginPage("/login")
					.failureUrl("/login-error")
					.successHandler(new AuthenticationSuccessHandlerImpl())
					.permitAll()
				.and()
					.logout()
					.logoutUrl("/logout").permitAll();
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/login").allowedOrigins("*").allowedMethods("POST")
				.exposedHeaders(SecurityConstants.AUTHORIZATION); // Header fica oculta por default, ent�o pra
																		// usar o token, precisa expor o header
	}
}
