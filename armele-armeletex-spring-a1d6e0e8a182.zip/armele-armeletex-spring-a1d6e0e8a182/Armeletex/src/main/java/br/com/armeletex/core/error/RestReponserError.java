package br.com.armeletex.core.error;

import org.springframework.validation.Errors;
import org.springframework.validation.ObjectError;

public class RestReponserError {

	private String error;

	private RestReponserError() {
	}

	public String getError() {
		return error;
	}

	public static RestReponserError fromValidationError(Errors erros) {
		RestReponserError resp = new RestReponserError();
		StringBuilder builder = new StringBuilder();
		for (ObjectError e : erros.getAllErrors()) {
			builder.append(e.getDefaultMessage()).append(". ");
		}
		resp.error = builder.toString();
		return resp;
	}
}
