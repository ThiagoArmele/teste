package br.com.armeletex.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import br.com.armeletex.cliente.Cliente;
import br.com.armeletex.cliente.ClienteRepository;

@Component
public class InsertTestDataCliente {

	@Autowired
	private ClienteRepository repository;

	@EventListener
	public void onApplicationEvent(ContextRefreshedEvent event) {
		if (repository.findByEmail("thiago4242@hotmail.com") == null) {
			PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
			Cliente cliente = new Cliente();
			cliente.setNome("Armeletex Admin");
			cliente.setAdmin(true);
			cliente.setAtivo(true);
			cliente.setEmail("thiago4242@hotmail.com");
			cliente.setCpf("41344935877");
			cliente.setSenha(encoder.encode("123"));
			repository.save(cliente);
		}

	}
}
