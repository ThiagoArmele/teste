package br.com.armeletex.core.security;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginController {

	@GetMapping(path =  {"/login", "/"})
	public String login() {
		return "login";
	}
	
	@GetMapping(path =  {"/login-error"})
	public String loginError(Model model) {
		model.addAttribute("error", "Inv�lido");
		return "login";
	}
	
}
