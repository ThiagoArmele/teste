package br.com.armeletex.empresa.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.armeletex.core.CrudController;
import br.com.armeletex.empresa.Empresa;
import br.com.armeletex.empresa.EmpresaRepository;

@RestController
@RequestMapping("/api/cliente/empresa")
public class EmpresaController extends CrudController<Empresa, EmpresaRepository> {

	}
