package br.com.armeletex.restaurante;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.br.CNPJ;

import lombok.Data;

@Data
@Entity
@Table(name = "tb_restaurante")
public class Restaurante {

	@Id
	@GeneratedValue
	@Column(name = "id_restaurante")
	private int id;

	@NotEmpty(message = "Nome obrigat�rio")
	@Size(max = 50, message = "Nome maior que o permitido")
	@Column(name = "nome", length = 50)
	private String nomeFantasia;

	@Email
	@NotEmpty(message = "E-mail obrigat�rio")
	@Size(max = 50, message = "E-mail maior que o permitido")
	@Column(name = "email")
	private String email;

	@Column(name = "ativo")
	private boolean ativo;

	@Column(name = "imagem_logo")
	private byte[] imagemLogo;
	
	@Size(max = 15, message = "Telefone maior que o permitido")
	@Column(name = "telefone", length = 15)
	private String telefone;

	@CNPJ(message = "CNPJ inv�lido")
	@Size(max = 14, message = "CNPJ maior que o permitido")
	@Column(name = "cnpj", length = 14)
	private String cnpj;

	@Column(name = "ie")
	private String ie;
}
