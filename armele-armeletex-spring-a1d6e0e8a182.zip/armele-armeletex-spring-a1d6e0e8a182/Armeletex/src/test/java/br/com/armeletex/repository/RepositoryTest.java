package br.com.armeletex.repository;

public abstract class RepositoryTest {

	abstract void insetUpdateFindDelete();
	
}
