package br.com.armeletex.repository;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import br.com.armeletex.cliente.Cliente;
import br.com.armeletex.cliente.ClienteRepository;

@DataJpaTest
@ActiveProfiles("test")
class ClienteRepositoryTest extends RepositoryTest {

	private static final String EMAIL_ALTERACAO = "teste_silva@gmail.com";
	private static final String EMAIL_INSERCAO = "teste_silva@gmail.com";

	@Autowired
	private ClienteRepository repository;

	@Test
	@Override
	void insetUpdateFindDelete() {
		// Inser��o
		Cliente cliente = new Cliente();
		cliente.setNome("T222");
		cliente.setAdmin(true);
		cliente.setAtivo(true);
		cliente.setEmail(EMAIL_INSERCAO);
		cliente.setCpf("41344935877");
		cliente.setSenha("123");
		repository.save(cliente);
		assertThat(cliente.getId()).isPositive();

		// Busca
		cliente = repository.findByEmail(EMAIL_INSERCAO);
		assertThat(cliente).isNotNull();

		// Altera��o
		cliente.setEmail(EMAIL_ALTERACAO);
		repository.save(cliente);
		cliente = repository.findByEmail(EMAIL_ALTERACAO);
		assertThat(cliente).isNotNull();

		// Remo��o
		repository.delete(cliente);
		cliente = repository.findByEmail(EMAIL_ALTERACAO);
		assertThat(cliente).isNull();
	}

}
