package br.com.armeletex.cliente;

import org.springframework.stereotype.Repository;

import br.com.armeletex.core.AppUserRepository;

@Repository
public interface ClienteRepository extends AppUserRepository<Cliente> {

}
