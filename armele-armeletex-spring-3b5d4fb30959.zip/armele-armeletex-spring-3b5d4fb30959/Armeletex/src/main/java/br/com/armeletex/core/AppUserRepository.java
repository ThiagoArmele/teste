package br.com.armeletex.core;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.NoRepositoryBean;

import br.com.armeletex.core.security.AppUser;

@NoRepositoryBean
public interface AppUserRepository<T extends AppUser> extends CrudRepository<T, Integer> {

	T findByEmail(String email);

}
