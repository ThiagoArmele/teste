package br.com.armeletex.restaurante;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;

@Data
@Entity
@Table(name = "tb_finalizadora")
public class Finalizadora {

	@Id
	@GeneratedValue
	@Column(name = "id_finalizadora")
	private int id;

	@NotEmpty(message = "Descri��o obrigat�rio")
	@Size(max = 30, message = "Nome maior que o permitido")
	@Column(name = "descricao", length = 30)
	private String descricao;

	@Column(name = "aceita_troco")
	private boolean aceitaTroco;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "id_restaurante")
	private Restaurante restaurante;
	
}
