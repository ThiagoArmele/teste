package br.com.armeletex.restaurate.mercadoria;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.armeletex.restaurante.Restaurante;
import lombok.Data;

@Data
@Entity
@Table(name = "tb_categoria")
public class Categoria {

	@Id
	@GeneratedValue
	@Column(name = "id_categoria")
	private int id;

	@Size(max = 100, message = "Descri��o maior que o permitido")
	@NotEmpty(message = "Descri��o obrigat�rio")
	@Column(name = "descricao", length = 100)
	private String descricao;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "id_restaurante")
	private Restaurante restaurante;

}