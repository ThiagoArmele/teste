package br.com.armeletex.empresa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Data;

@Data
@Entity
@Table(name = "tb_empresa")
public class Empresa {

	@Id
	@GeneratedValue
	@Column(name = "id_empresa")
	private int id;

	@NotEmpty(message = "Nome Fantasia obrigat�rio")
	@Size(max = 100, message = "Nome Fantasia maior que o permitido")
	@Column(name = "nome_fantasia", length = 100)
	private String nomeFantasia;

}
