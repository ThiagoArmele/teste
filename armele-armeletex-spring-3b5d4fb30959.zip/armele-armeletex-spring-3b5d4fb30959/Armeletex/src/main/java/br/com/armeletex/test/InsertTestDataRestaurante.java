package br.com.armeletex.test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import br.com.armeletex.restaurante.Finalizadora;
import br.com.armeletex.restaurante.FinalizadoraRepository;
import br.com.armeletex.restaurante.Restaurante;
import br.com.armeletex.restaurante.RestauranteFuncionario;
import br.com.armeletex.restaurante.RestauranteFuncionarioRepository;
import br.com.armeletex.restaurante.RestauranteRepository;

@Component
public class InsertTestDataRestaurante {

	@Autowired
	private RestauranteRepository restauranteRepository;
	
	@Autowired
	private RestauranteFuncionarioRepository restauranteFuncionarioRepository;

	@Autowired
	private FinalizadoraRepository finalizadoraRepository;
	
	@EventListener
	public void onApplicationEvent(ContextRefreshedEvent event) {
		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
		if (restauranteRepository.findByEmail("restaurante@restaurante.com.br") == null) {
			Restaurante restaurante = new Restaurante();
			restaurante.setCnpj("87054392000150");
			restaurante.setEmail("restaurante@restaurante.com.br");
			restaurante.setNomeFantasia("Restaurante Teste");
			restaurante.setTelefone("19997182707");
			Restaurante restauranteSalvo = restauranteRepository.save(restaurante);
			
			RestauranteFuncionario rf = new RestauranteFuncionario();
			rf.setNome("Funcion�rio 1");
			rf.setEmail("funcionario1@teste.com.br");
			rf.setRestaurante(restauranteSalvo);
			rf.setSenha(encoder.encode("123"));
			restauranteFuncionarioRepository.save(rf);
			
			Finalizadora finalizadora = new Finalizadora();
			finalizadora.setDescricao("Dinheiro");
			finalizadora.setRestaurante(restauranteSalvo);
			finalizadoraRepository.save(finalizadora);
		}
		
		if (restauranteRepository.findByEmail("restaurante2@restaurante.com.br") == null) {
			Restaurante restaurante = new Restaurante();
			restaurante.setCnpj("69991542000170");
			restaurante.setEmail("restaurante@restaurante2.com.br");
			restaurante.setNomeFantasia("Restaurante 2 Teste");
			restaurante.setTelefone("19997182707");
			Restaurante restauranteSalvo = restauranteRepository.save(restaurante);
			
			RestauranteFuncionario rf = new RestauranteFuncionario();
			rf.setNome("Funcion�rio 2");
			rf.setEmail("funcionario2@teste.com.br");
			rf.setRestaurante(restauranteSalvo);
			rf.setSenha(encoder.encode("123"));
			restauranteFuncionarioRepository.save(rf);
			
			Finalizadora finalizadora = new Finalizadora();
			finalizadora.setDescricao("Dinheiro");
			finalizadora.setRestaurante(restauranteSalvo);
			finalizadoraRepository.save(finalizadora);
		}
		
 	}
}
