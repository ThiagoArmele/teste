package br.com.armeletex.core.security;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@MappedSuperclass
public class AppUser {

	@Email(message = "E-mail inv�lido")
	@NotEmpty(message = "E-mail obrigat�rio")
	@Size(max = 50, message = "E-mail maior que o permitido")
	@Column(name = "email", length = 50)
	private String email;

	@NotEmpty(message = "Senha obrigat�rio")
	@Column(name = "senha")
	private String senha;

	@NotEmpty(message = "Nome obrigat�rio")
	@Size(max = 50, message = "Nome maior que o permitido")
	@Column(name = "nome", length = 50)
	private String nome;
	
	@Column(name = "ativo")
	private boolean ativo;
}
