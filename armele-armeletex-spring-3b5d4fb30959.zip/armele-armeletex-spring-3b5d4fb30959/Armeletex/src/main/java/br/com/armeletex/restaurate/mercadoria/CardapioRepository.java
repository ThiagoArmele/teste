package br.com.armeletex.restaurate.mercadoria;

public interface CardapioRepository {

}
