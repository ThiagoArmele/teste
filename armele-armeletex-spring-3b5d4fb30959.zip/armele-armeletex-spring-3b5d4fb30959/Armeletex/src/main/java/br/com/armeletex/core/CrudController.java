package br.com.armeletex.core;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

public abstract class CrudController<T, R extends CrudRepository<T, Integer>> {

	@Autowired
	private R repository;

	@GetMapping("/lista")
	public List<T> listAll() {
		return (List<T>) repository.findAll();
	}

	@PostMapping
	public T save(@RequestBody T t) {
		return repository.save(t);
	}

	@PutMapping(value = "/{id}")
	public T update(@RequestBody T t) {
		return repository.save(t);
	}

	@DeleteMapping(path = { "/{id}" })
	public void delete(@PathVariable Integer id) {
		repository.deleteById(id);
	}

}
