package br.com.armeletex.restaurate.mercadoria;

public class CardapioTipo {

}
