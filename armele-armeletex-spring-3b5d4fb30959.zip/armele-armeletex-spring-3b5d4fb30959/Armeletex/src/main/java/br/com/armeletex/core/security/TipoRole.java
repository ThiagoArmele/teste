package br.com.armeletex.core.security;

public enum TipoRole {

	CLIENTE,
	RESTAURANTE;
}
