package br.com.armeletex.restaurate.mercadoria;

import br.com.armeletex.core.CrudRestaurantRepository;

public interface MercadoriaRepository extends CrudRestaurantRepository<Mercadoria> {

}
