package br.com.armeletex.restaurante;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RestauranteRepository extends CrudRepository<Restaurante, Integer> {

	Restaurante findByEmail(String email);

}
