package br.com.armeletex.core.security;

import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import br.com.armeletex.cliente.Cliente;
import br.com.armeletex.restaurante.RestauranteFuncionario;

public class UserDetailsImpl implements UserDetails {

	private static final long serialVersionUID = -1265148813619357814L;
	private String email;
	private String senha;
	private String nome;
	private boolean ativo;
	private TipoRole role;
	private Collection<? extends GrantedAuthority> roles;

	public UserDetailsImpl(AppUser appUser) {
		this.email = appUser.getEmail();
		this.senha = appUser.getSenha();
		this.nome = appUser.getNome();

		if (appUser instanceof Cliente) {
			role = TipoRole.CLIENTE;
		} else if (appUser instanceof RestauranteFuncionario) {
			role = TipoRole.RESTAURANTE;
		} else {
			throw new IllegalStateException("Usu�rio n�o � v�lido");
		}

		ativo = appUser.isAtivo();
		roles = List.of(new SimpleGrantedAuthority("ROLE_" + role));
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return roles;
	}

	@Override
	public String getPassword() {
		return senha;
	}

	@Override
	public String getUsername() {
		return email;
	}

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return ativo;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	public String getNome() {
		return nome;
	}

	public TipoRole getRole() {
		return role;
	}
}
