package br.com.armeletex.restaurate.mercadoria;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.armeletex.restaurante.Restaurante;
import lombok.Data;

@Data
@Entity
@Table(name = "tb_mercadoria")
public class Mercadoria {

	@Id
	@GeneratedValue
	@Column(name = "id_produto")
	private int id;

	@Size(max = 100, message = "Nome maior que o permitido")
	@NotEmpty(message = "Nome obrigat�rio")
	@Column(name = "nome", length = 100)
	private String nome;

	@Size(max = 100, message = "Descri��o maior que o permitido")
	@NotEmpty(message = "Descri��o obrigat�rio")
	@Column(name = "descricao", length = 150)
	private String descricao;

	@JsonIgnore
	@ManyToOne
	@JoinColumn(name = "id_restaurante")
	private Restaurante restaurante;

	@ManyToOne
	@JoinColumn(name = "id_categoria")
	private Categoria categoria;

	@Column(name = "preco")
	private Double preco;

	@Column(name = "preco_desconto")
	private double precoDesconto;

	@Column(name = "dt_inicial")
	private LocalDate dataInicial;

	@Column(name = "dt_final")
	private LocalDate dataFinal;

	@Column(name = "ativo")
	private boolean ativo;
}
