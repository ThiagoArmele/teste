package br.com.armeletex.restaurante.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.armeletex.core.CrudController;
import br.com.armeletex.restaurante.Finalizadora;
import br.com.armeletex.restaurante.FinalizadoraRepository;

@RestController
@RequestMapping("/api/restaurante/finalizadora")
public class FinalizadoraController extends CrudController<Finalizadora, FinalizadoraRepository> {


}
