package br.com.armeletex.restaurante;

import br.com.armeletex.core.CrudRestaurantRepository;

public interface FinalizadoraRepository extends CrudRestaurantRepository<Finalizadora> {

}
